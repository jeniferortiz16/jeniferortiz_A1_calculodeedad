/******************************************************************************

                           Lenguaje de Programacion I 
                           Calculo de Edad

*******************************************************************************/
#include <iostream>
#include <stdio.h>

int main()
{
    int edad;
    std::cout <<"Ingrese su edad:";
    std::cin >>edad;
    
    if (edad>17) {
        std::cout << "Usted es mayor de edad." << std::ends;
    } else {
        std::cout << "Usted es menor de edad." << std::ends;
    }
    
    return 0;
}
